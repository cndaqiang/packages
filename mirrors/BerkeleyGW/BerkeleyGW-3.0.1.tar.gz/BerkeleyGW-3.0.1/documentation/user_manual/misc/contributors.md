# Contributors

## Alphabetical list of contributors

- Gabriel K. Antonius (GKA)
- Brad A. Barker (BAB)
- Xavier Blase (XAV)
- Andrew Canning (AC)
- Andrea Cepellotti (ACE)
- Eric K. Chang (EKC)
- Sangkook Choi (SKC)
- Mauro Del Ben (MDB)
- Jack R. Deslippe (JRD)
- Peter W. Doak (PWD)
- Mark S. Hybertsen (MSH)
- Sohrab Ismail-Beigi (SIB)
- Manish Jain (MJ)
- Felipe H. da Jornada (FHJ)
- Je-Luen Li (JLL)
- Zhenglu Li (ZL)
- Steven G. Louie (SGL)
- Andrei S. Malashevich (ASM)
- Brad D. Malone (BDM)
- Jamal I. Mustafa (JIM)
- Jeffrey B. Neaton (JBN)
- Cheol-Hwan Park (CHP)
- David G. Prendergast (DGP)
- Diana Y. Qiu (DYQ)
- Tonatiuh Rangel (TR)
- Filipe J. Ribeiro (FJR)
- Gian-Marco Rignanese (GMR)
- Georgy Samsonidze (GSM)
- Sahar Sharifzadeh (SS)
- Catalin D. Spataru (CDS)
- David A. Strubbe (DAS)
- Murilo L. Tiago (MLT)
- Derek Vigil-Fowler (DVF)
- Li Yang (LY)
- Oleg V. Yazyev (OVY)
- Peihong Zhang (PZ)


## Changelog

- Version 1.2 (Aug, 2016):

    F. H. da Jornada, J. Deslippe, D. Vigil-Fowler, J. I. Mustafa, T. Rangel,
    F. Bruneval, F. Liu, D. Y. Qiu, D. A. Strubbe, G. Samsonidze, J. Lischner.

- Version 1.1 (June, 2014):

- Version 1.0 (Aug, 2011):

    J. Deslippe, G. Samsonidze, D. A. Strubbe, M. Jain

- Version 0.5 (July, 2008):

    J. Deslippe, G. Samsonidze, L. Yang, F. Ribeiro

- Version 0.2:

    M. L. Tiago (2001) Original BSE Code, PlotXct

    S. Ismail-Beigi (2002) FFT, Documentation, General Improvements

    C. Spataru (2005) Cylindrical Coulomb Truncation, Transform (obsolete)

- Version 0.1:

    X. Blase, G. M. Rignanese, E. Chang (1998) Implemented F90, Preprocessing, Dynamical Memory Allocation

- Version 0.0

    M. Hybertsen (1985) Original GW Code
