# `bgw2sgw`

`bgw2sgw` is a wrapper that converts the charge density (`RHO`) and
wavefunctions (`WFN` or `WFN.h5`) in BerkeleyGW format to the format used in
the [StochasticGW](http://stochasticgw.com) code. Please, refer to the input
file [`bgw2sgw.inp`](bgw2sgw-keywords.md) for further information.
