* Imported spglib-1.0.9 from http://spglib.sourceforge.net. This is a BSD-licensed C library for symmetries by Atsushi Togo. --DAS
* Added src/spglib_f.c which is not actually part of spglib 1.0.9 although it appears to have been forgotten by accident since it is mentioned in the documentation and was present in earlier version. I obtained it by e-mailing the author. --DAS
* Removed test directory which we do not need and contains a large number of files. --DAS
* Removed examples, python, etc., blank files, and automake/libtool-related files. --DAS
