[% FOR page IN pages %]
================
[% page.title %]
================
[% page.body %]
[% END %]
