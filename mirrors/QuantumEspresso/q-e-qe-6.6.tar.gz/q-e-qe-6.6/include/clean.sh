#!/bin/bash

\rm -f c_defs.h configure.h >& /dev/null
